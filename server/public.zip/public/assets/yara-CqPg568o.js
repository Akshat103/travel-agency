const s="/assets/yara-DtT0JTJJ.png";export{s as i};
