import React, { useState, useEffect } from 'react';
import { FaEdit } from 'react-icons/fa';
import { Modal, Button, Card, Form } from 'react-bootstrap';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import { MdCancel, MdDelete } from "react-icons/md";

const Profile = () => {
    const [user, setUser] = useState(null);
    const [editMode, setEditMode] = useState(false);
    const [showDeleteModal, setShowDeleteModal] = useState(false);
    const [updatedUser, setUpdatedUser] = useState({});
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUser = async () => {
            try {
                const response = await axios.get('/api/user-by-id');
                setUser(response.data);
            } catch (error) {
                toast.error(error.response.data.message);
                if(error.response.status===401){
                    navigate(error.response.data.redirect);
                }
            }
        };
        fetchUser();
    }, []);

    const handleEdit = () => {
        setEditMode(true);
        setUpdatedUser({
            name: user.name,
            email: user.email,
            mobileNumber: user.mobileNumber,
            gender: user.gender,
            dateOfBirth: new Date(user.dateOfBirth).toISOString().substring(0, 10),
            state: user.state,
        });
    };

    const handleDelete = async () => {
        try {
            await axios.delete('/api/delete-user');
            toast.info('User deleted successfully');
            localStorage.clear();
            navigate('/');
        } catch (error) {
            console.error(error);
        }
        setShowDeleteModal(false);
    };

    const handleUpdate = async () => {
        try {
            await axios.put('/api/update-user', updatedUser);
            toast.success('User updated successfully');
            setUser({ ...user, ...updatedUser });
            setEditMode(false);
        } catch (error) {
            console.error(error);
            toast.error('User updated failed');
        }
    };

    const handleChange = (e) => {
        setUpdatedUser({ ...updatedUser, [e.target.name]: e.target.value });
    };

    return (
        <div className="container mt-5 ">
            {user ? (
                <Card style={{ border: "none" }}>
                    <Card.Body className="d-flex flex-column flex-lg-row justify-content-between align-items-center">
                        {editMode ? (
                            <div className="container align-item-center">
                                <div className="row mb-3">
                                    <div className="col-md-4">
                                        <Card.Text>
                                            <Form.Control
                                                type="text"
                                                name="name"
                                                value={updatedUser.name}
                                                onChange={handleChange}
                                                placeholder="Name"
                                            />
                                        </Card.Text>

                                    </div>
                                    <div className="col-md-4">
                                        <Card.Text>
                                            {editMode ? (
                                                <Form.Control
                                                    type="email"
                                                    name="email"
                                                    value={updatedUser.email}
                                                    onChange={handleChange}
                                                    placeholder="Email"
                                                />
                                            ) : <></>}
                                        </Card.Text>
                                    </div>
                                    <div className="col-md-4">
                                        <Card.Text>
                                            {editMode ? (
                                                <Form.Control
                                                    type="text"
                                                    name="mobileNumber"
                                                    value={updatedUser.mobileNumber}
                                                    onChange={handleChange}
                                                    placeholder="Mobile Number"
                                                />
                                            ) : <></>}
                                        </Card.Text>
                                    </div>
                                </div>

                                <div className="row mb-3">
                                    <div className="col-md-4">
                                        <Card.Text>
                                            {editMode ? (
                                                <Form.Control
                                                    as="select"
                                                    name="gender"
                                                    value={updatedUser.gender}
                                                    onChange={handleChange}
                                                >
                                                    <option value="">Select Gender</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                    <option value="Other">Other</option>
                                                </Form.Control>
                                            ) : <></>}
                                        </Card.Text>
                                    </div>
                                    <div className="col-md-4">
                                        <Card.Text>
                                            {editMode ? (
                                                <Form.Control
                                                    type="date"
                                                    name="dateOfBirth"
                                                    value={updatedUser.dateOfBirth}
                                                    onChange={handleChange}
                                                />
                                            ) : <></>}
                                        </Card.Text>
                                    </div>
                                    <div className="col-md-4">
                                        <Card.Text>
                                            {editMode ? (
                                                <Form.Control
                                                    type="text"
                                                    name="state"
                                                    value={updatedUser.state}
                                                    onChange={handleChange}
                                                    placeholder="State"
                                                />
                                            ) : <></>}
                                        </Card.Text>
                                    </div>
                                </div>
                            </div>
                        ) : (
                            <div>
                                <h5><strong>Welcome {user.name}</strong></h5>
                            </div>
                        )}
                        <div className='p-2'>
                        {!editMode && (
                            <Button
                                style={{ width: "2.6rem", height: "2.4rem" }}
                                variant="primary"
                                onClick={handleEdit}
                                className='mx-2'
                            >
                                <FaEdit />
                            </Button>
                            )}
                            <Button
                                variant="danger"
                                style={{ width: "2.6rem", height: "2.4rem" }}
                                onClick={() => setShowDeleteModal(true)}
                                className='mx-2'
                            >
                                <MdDelete />
                            </Button>
                        </div>
                    </Card.Body>
                </Card>
            ) : (
                <p>Loading...</p>
            )}

            {/* Delete Confirmation Modal */}
            <Modal show={showDeleteModal} onHide={() => setShowDeleteModal(false)}>
                <Modal.Header closeButton>
                    <Modal.Title>Confirm Delete</Modal.Title>
                </Modal.Header>
                <Modal.Body>Are you sure you want to delete this user?</Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={() => setShowDeleteModal(false)}>
                        <MdCancel />
                    </Button>
                    <Button variant="danger" onClick={handleDelete}>
                        <MdDelete />
                    </Button>
                </Modal.Footer>
            </Modal>

            {editMode && (
                <div className="d-flex justify-content-center">
                    <Button variant="success" onClick={handleUpdate}>
                        Save
                    </Button>
                </div>
            )}
        </div>
    );
};

export default Profile;
