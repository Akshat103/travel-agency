import React from 'react';
import { Card } from 'react-bootstrap';
import RechargeDetailsCard from './Cards/RechargeDetailsCard';
import FlightCard from './Cards/FlightCard';
import BusCard from './Cards/BusCard';

const OrderCard = ({ order }) => {
    const { serviceType, serviceDetails, amount, currency, status } = order;

    const renderCardContent = () => {
        switch (serviceType) {
            case 'bookbus':
                return (
                    <>
                        <BusCard order={order} />
                    </>
                );

            case 'recharge':
                return (
                    <>
                        <RechargeDetailsCard order={order} />
                    </>
                );

            case 'bookflight':
                return (
                    <>
                        <FlightCard order={order} />
                    </>
                );

            default:
                return (
                    <>
                    </>
                );
        }
    };

    return (
        <>{renderCardContent()}</>
    );
};

export default OrderCard;
