import React from 'react';
import { Card, Col, Row, ListGroup, Button } from 'react-bootstrap';
import { FaCheckCircle, FaTimesCircle, FaMobileAlt } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const RechargeDetailsCard = ({ order }) => {
    const { serviceDetails, amount, currency, status } = order;

    const navigate = useNavigate();

    const handleRechargeAgain = () => {
        navigate('/mobile-recharge');
    };

    return (
        <Card className="p-3 my-3 shadow-sm">
            <Card.Header as="h5" className="text-center">
                <FaMobileAlt className="me-2" /> Recharge
            </Card.Header>

            <Card.Body>
                <Row>
                    <Col md={6}>
                        <ListGroup variant="flush">
                            <ListGroup.Item><strong>Number:</strong> {serviceDetails.number}</ListGroup.Item>
                        </ListGroup>
                    </Col>
                    <Col md={6}>
                        <ListGroup variant="flush">
                            <ListGroup.Item>
                                <strong>Amount:</strong> {amount} {currency}
                                {status === 'paid' ? <FaCheckCircle className="text-success ms-2" /> : <FaTimesCircle className="text-danger ms-2" />}
                            </ListGroup.Item>
                        </ListGroup>
                    </Col>
                </Row>

                <hr />

                {/* Recharge Again Button */}
                <div className="text-center">
                    <Button variant="primary" onClick={handleRechargeAgain}>
                        Recharge Again
                    </Button>
                </div>
            </Card.Body>

        </Card>
    );
};

export default RechargeDetailsCard;
