import React from 'react';
import { Card, Row, Col, ListGroup, Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const BusCard = ({ order }) => {
    if (!order) {
        return <div>No order data available</div>;
    }

    const { serviceDetails, amount, currency, status } = order;
    const { sourceName, destinationName, doj, seats } = serviceDetails || {};
    const { passengername, seatname } = seats[0] || {};

    const navigate = useNavigate();

    const handleBookAgain = () => {
        navigate('/bus');
    };

    return (
        <Card className="p-3 my-3 shadow-sm">
            <Card.Header as="h5" className="text-center">
                Bus Ticket Details
            </Card.Header>

            <Card.Body>
                <Row>
                    <Col md={6}>
                        <ListGroup variant="flush">
                            <ListGroup.Item>
                                <strong>From:</strong> {sourceName || 'N/A'}
                            </ListGroup.Item>
                            <ListGroup.Item>
                                <strong>To:</strong> {destinationName || 'N/A'}
                            </ListGroup.Item>
                            <ListGroup.Item>
                                <strong>Date of Journey:</strong> {doj ? new Date(doj).toLocaleDateString() : 'N/A'}
                            </ListGroup.Item>
                        </ListGroup>
                    </Col>
                    <Col md={6}>
                        <ListGroup variant="flush">
                            <ListGroup.Item>
                                <strong>Passenger Name:</strong> {passengername || 'N/A'}
                            </ListGroup.Item>
                            <ListGroup.Item>
                                <strong>Seat Number:</strong> {seatname || 'N/A'}
                            </ListGroup.Item>
                            <ListGroup.Item>
                                <strong>Total Amount:</strong> {currency ? `${currency} ${amount}` : 'N/A'}
                            </ListGroup.Item>
                        </ListGroup>
                    </Col>
                </Row>
            </Card.Body>
            <Card.Footer className="text-center">
                <Button variant="primary" onClick={handleBookAgain}>
                    Book Again
                </Button>
            </Card.Footer>
        </Card>
    );
};

export default BusCard;
