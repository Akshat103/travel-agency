import React, { useState, useEffect } from 'react';
import { Card, Row, Col, ListGroup, Button, Spinner } from 'react-bootstrap';
import { FaPlaneDeparture } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const FlightCard = ({ order }) => {
    const navigate = useNavigate();
    const [bookingRef, setBookingRef] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (order?.serviceResponse?.Booking_RefNo) {
            setBookingRef(order.serviceResponse.Booking_RefNo);
            setLoading(false);
        } else {
            const checkBookingRef = setInterval(() => {
                if (order?.serviceResponse?.Booking_RefNo) {
                    setBookingRef(order.serviceResponse.Booking_RefNo);
                    setLoading(false);
                    clearInterval(checkBookingRef);
                }
            }, 500);

            return () => clearInterval(checkBookingRef);
        }
    }, [order]);

    const handleBookAgain = () => {
        navigate('/flights');
    };

    if (!order) {
        return <div>No order data available</div>;
    }

    const { serviceDetails, amount, currency, status } = order;
    const { flightDetails } = serviceDetails || {};
    const { Origin, Destination, TravelDate } = flightDetails || {};

    return (
        <Card className="p-3 my-3 shadow-sm">
            <Card.Header as="h5" className="text-center">
                <FaPlaneDeparture className="me-2" /> Flight Details
            </Card.Header>

            <Card.Body>
                <Row>
                    <Col md={6}>
                        <ListGroup variant="flush">
                            <ListGroup.Item>
                                <strong>Origin:</strong> {Origin?.AIRPORTCODE || 'N/A'}
                            </ListGroup.Item>
                            <ListGroup.Item>
                                <strong>Destination:</strong> {Destination?.AIRPORTCODE || 'N/A'}
                            </ListGroup.Item>
                            <ListGroup.Item>
                                <strong>Travel Date:</strong> {TravelDate ? new Date(TravelDate).toLocaleDateString() : 'N/A'}
                            </ListGroup.Item>
                        </ListGroup>
                    </Col>
                    <Col md={6}>
                        <ListGroup variant="flush">
                            <ListGroup.Item>
                                <strong>Total Amount:</strong> {currency ? `${currency} ${amount}` : 'N/A'}
                            </ListGroup.Item>
                            <ListGroup.Item>
                                <strong>Booking Reference No:</strong>
                                {loading ? (
                                    <Spinner animation="border" size="sm" className="ms-2" />
                                ) : (
                                    <span className="ms-2">{bookingRef || 'N/A'}</span>
                                )}
                            </ListGroup.Item>
                        </ListGroup>
                    </Col>
                </Row>
            </Card.Body>

            <Card.Footer className="text-center">
                <Button variant="primary" onClick={handleBookAgain}>
                    Book Again
                </Button>
            </Card.Footer>
        </Card>
    );
};

export default FlightCard;