import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import OrderCard from './OrderCard';

const OrdersList = () => {
    const [orders, setOrders] = useState([]);
    const [displayedOrders, setDisplayedOrders] = useState([]);
    const [hasMore, setHasMore] = useState(true);
    const containerRef = useRef(null);
    const LOAD_MORE_COUNT = 20;

    const fetchOrders = async () => {
        try {
            const res = await axios.get('/api/dashboard/orders');
            setOrders(res.data.orders);
            setDisplayedOrders(res.data.orders.slice(0, LOAD_MORE_COUNT));
            if (res.data.orders.length <= LOAD_MORE_COUNT) {
                setHasMore(false);
            }
        } catch (error) {
            console.error(error.response.data.message);
        }
    };

    useEffect(() => {
        fetchOrders();
    }, []);

    // Function to load more orders as the user scrolls
    const loadMore = () => {
        if (displayedOrders.length < orders.length) {
            setDisplayedOrders((prev) => [
                ...prev,
                ...orders.slice(prev.length, prev.length + LOAD_MORE_COUNT),
            ]);
        } else {
            setHasMore(false);
        }
    };

    // Handle the scroll event
    useEffect(() => {
        const handleScroll = () => {
            const { scrollTop, clientHeight, scrollHeight } = containerRef.current;
            if (scrollTop + clientHeight >= scrollHeight && hasMore) {
                loadMore();
            }
        };

        const ref = containerRef.current;
        if (ref) {
            ref.addEventListener('scroll', handleScroll);
        }

        // Cleanup the event listener on component unmount
        return () => ref && ref.removeEventListener('scroll', handleScroll);
    }, [displayedOrders, orders, hasMore]);

    return (
        <div className='container  mt-4'>
            <h4 className='m-2'>Orders</h4>
            <div
                ref={containerRef}
                style={{ height: 'calc(100vh - 80px)', overflowY: 'auto' }}
                className="scroll-container"
            >
                {displayedOrders.length > 0 ? (
                    displayedOrders.map((order) => (
                        <OrderCard key={order.orderId} order={order} />
                    ))
                ) : (
                    <p>No orders available</p>
                )}
                {hasMore && <h4>Loading more orders...</h4>}
                {!hasMore && <p>No more orders to show</p>}
            </div>
        </div>
    );
};

export default OrdersList;
