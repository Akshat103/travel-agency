import React from 'react';

const flightData = {
    "data": [
        [
            {
                "SSR_TypeDesc": "SEAT - 1A",
                "SSR_TypeName": "1A"
            },
            {
                "SSR_TypeDesc": "SEAT - 1B",
                "SSR_TypeName": "1B"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 2A",
                "SSR_TypeName": "2A"
            },
            {
                "SSR_TypeDesc": "SEAT - 2B",
                "SSR_TypeName": "2B"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 3A",
                "SSR_TypeName": "3A"
            },
            {
                "SSR_TypeDesc": "SEAT - 3B",
                "SSR_TypeName": "3B"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 4A",
                "SSR_TypeName": "4A"
            },
            {
                "SSR_TypeDesc": "SEAT - 4B",
                "SSR_TypeName": "4B"
            },
            {
                "SSR_TypeDesc": "SEAT - 4C",
                "SSR_TypeName": "4C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 4D",
                "SSR_TypeName": "4D"
            },
            {
                "SSR_TypeDesc": "SEAT - 4E",
                "SSR_TypeName": "4E"
            },
            {
                "SSR_TypeDesc": "SEAT - 4F",
                "SSR_TypeName": "4F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 5A",
                "SSR_TypeName": "5A"
            },
            {
                "SSR_TypeDesc": "SEAT - 5B",
                "SSR_TypeName": "5B"
            },
            {
                "SSR_TypeDesc": "SEAT - 5C",
                "SSR_TypeName": "5C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 5D",
                "SSR_TypeName": "5D"
            },
            {
                "SSR_TypeDesc": "SEAT - 5E",
                "SSR_TypeName": "5E"
            },
            {
                "SSR_TypeDesc": "SEAT - 5F",
                "SSR_TypeName": "5F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 6A",
                "SSR_TypeName": "6A"
            },
            {
                "SSR_TypeDesc": "SEAT - 6B",
                "SSR_TypeName": "6B"
            },
            {
                "SSR_TypeDesc": "SEAT - 6C",
                "SSR_TypeName": "6C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 6D",
                "SSR_TypeName": "6D"
            },
            {
                "SSR_TypeDesc": "SEAT - 6E",
                "SSR_TypeName": "6E"
            },
            {
                "SSR_TypeDesc": "SEAT - 6F",
                "SSR_TypeName": "6F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 7A",
                "SSR_TypeName": "7A"
            },
            {
                "SSR_TypeDesc": "SEAT - 7B",
                "SSR_TypeName": "7B"
            },
            {
                "SSR_TypeDesc": "SEAT - 7C",
                "SSR_TypeName": "7C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 7D",
                "SSR_TypeName": "7D"
            },
            {
                "SSR_TypeDesc": "SEAT - 7E",
                "SSR_TypeName": "7E"
            },
            {
                "SSR_TypeDesc": "SEAT - 7F",
                "SSR_TypeName": "7F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 8A",
                "SSR_TypeName": "8A"
            },
            {
                "SSR_TypeDesc": "SEAT - 8B",
                "SSR_TypeName": "8B"
            },
            {
                "SSR_TypeDesc": "SEAT - 8C",
                "SSR_TypeName": "8C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 8D",
                "SSR_TypeName": "8D"
            },
            {
                "SSR_TypeDesc": "SEAT - 8E",
                "SSR_TypeName": "8E"
            },
            {
                "SSR_TypeDesc": "SEAT - 8F",
                "SSR_TypeName": "8F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 9A",
                "SSR_TypeName": "9A"
            },
            {
                "SSR_TypeDesc": "SEAT - 9B",
                "SSR_TypeName": "9B"
            },
            {
                "SSR_TypeDesc": "SEAT - 9C",
                "SSR_TypeName": "9C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 9D",
                "SSR_TypeName": "9D"
            },
            {
                "SSR_TypeDesc": "SEAT - 9E",
                "SSR_TypeName": "9E"
            },
            {
                "SSR_TypeDesc": "SEAT - 9F",
                "SSR_TypeName": "9F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 10A",
                "SSR_TypeName": "10A"
            },
            {
                "SSR_TypeDesc": "SEAT - 10B",
                "SSR_TypeName": "10B"
            },
            {
                "SSR_TypeDesc": "SEAT - 10C",
                "SSR_TypeName": "10C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 10D",
                "SSR_TypeName": "10D"
            },
            {
                "SSR_TypeDesc": "SEAT - 10E",
                "SSR_TypeName": "10E"
            },
            {
                "SSR_TypeDesc": "SEAT - 10F",
                "SSR_TypeName": "10F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 11A",
                "SSR_TypeName": "11A"
            },
            {
                "SSR_TypeDesc": "SEAT - 11B",
                "SSR_TypeName": "11B"
            },
            {
                "SSR_TypeDesc": "SEAT - 11C",
                "SSR_TypeName": "11C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 11D",
                "SSR_TypeName": "11D"
            },
            {
                "SSR_TypeDesc": "SEAT - 11E",
                "SSR_TypeName": "11E"
            },
            {
                "SSR_TypeDesc": "SEAT - 11F",
                "SSR_TypeName": "11F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 12A",
                "SSR_TypeName": "12A"
            },
            {
                "SSR_TypeDesc": "SEAT - 12B",
                "SSR_TypeName": "12B"
            },
            {
                "SSR_TypeDesc": "SEAT - 12C",
                "SSR_TypeName": "12C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 12D",
                "SSR_TypeName": "12D"
            },
            {
                "SSR_TypeDesc": "SEAT - 12E",
                "SSR_TypeName": "12E"
            },
            {
                "SSR_TypeDesc": "SEAT - 12F",
                "SSR_TypeName": "12F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 13A",
                "SSR_TypeName": "13A"
            },
            {
                "SSR_TypeDesc": "SEAT - 13B",
                "SSR_TypeName": "13B"
            },
            {
                "SSR_TypeDesc": "SEAT - 13C",
                "SSR_TypeName": "13C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 14A",
                "SSR_TypeName": "14A"
            },
            {
                "SSR_TypeDesc": "SEAT - 14B",
                "SSR_TypeName": "14B"
            },
            {
                "SSR_TypeDesc": "SEAT - 14C",
                "SSR_TypeName": "14C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 14D",
                "SSR_TypeName": "14D"
            },
            {
                "SSR_TypeDesc": "SEAT - 14E",
                "SSR_TypeName": "14E"
            },
            {
                "SSR_TypeDesc": "SEAT - 14F",
                "SSR_TypeName": "14F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 15A",
                "SSR_TypeName": "15A"
            },
            {
                "SSR_TypeDesc": "SEAT - 15B",
                "SSR_TypeName": "15B"
            },
            {
                "SSR_TypeDesc": "SEAT - 15C",
                "SSR_TypeName": "15C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 15D",
                "SSR_TypeName": "15D"
            },
            {
                "SSR_TypeDesc": "SEAT - 15E",
                "SSR_TypeName": "15E"
            },
            {
                "SSR_TypeDesc": "SEAT - 15F",
                "SSR_TypeName": "15F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 16A",
                "SSR_TypeName": "16A"
            },
            {
                "SSR_TypeDesc": "SEAT - 16B",
                "SSR_TypeName": "16B"
            },
            {
                "SSR_TypeDesc": "SEAT - 16C",
                "SSR_TypeName": "16C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 16D",
                "SSR_TypeName": "16D"
            },
            {
                "SSR_TypeDesc": "SEAT - 16E",
                "SSR_TypeName": "16E"
            },
            {
                "SSR_TypeDesc": "SEAT - 16F",
                "SSR_TypeName": "16F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 17A",
                "SSR_TypeName": "17A"
            },
            {
                "SSR_TypeDesc": "SEAT - 17B",
                "SSR_TypeName": "17B"
            },
            {
                "SSR_TypeDesc": "SEAT - 17C",
                "SSR_TypeName": "17C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 17D",
                "SSR_TypeName": "17D"
            },
            {
                "SSR_TypeDesc": "SEAT - 17E",
                "SSR_TypeName": "17E"
            },
            {
                "SSR_TypeDesc": "SEAT - 17F",
                "SSR_TypeName": "17F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 18A",
                "SSR_TypeName": "18A"
            },
            {
                "SSR_TypeDesc": "SEAT - 18B",
                "SSR_TypeName": "18B"
            },
            {
                "SSR_TypeDesc": "SEAT - 18C",
                "SSR_TypeName": "18C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 18D",
                "SSR_TypeName": "18D"
            },
            {
                "SSR_TypeDesc": "SEAT - 18E",
                "SSR_TypeName": "18E"
            },
            {
                "SSR_TypeDesc": "SEAT - 18F",
                "SSR_TypeName": "18F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 19A",
                "SSR_TypeName": "19A"
            },
            {
                "SSR_TypeDesc": "SEAT - 19B",
                "SSR_TypeName": "19B"
            },
            {
                "SSR_TypeDesc": "SEAT - 19C",
                "SSR_TypeName": "19C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 19D",
                "SSR_TypeName": "19D"
            },
            {
                "SSR_TypeDesc": "SEAT - 19E",
                "SSR_TypeName": "19E"
            },
            {
                "SSR_TypeDesc": "SEAT - 19F",
                "SSR_TypeName": "19F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 20A",
                "SSR_TypeName": "20A"
            },
            {
                "SSR_TypeDesc": "SEAT - 20B",
                "SSR_TypeName": "20B"
            },
            {
                "SSR_TypeDesc": "SEAT - 20C",
                "SSR_TypeName": "20C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 20D",
                "SSR_TypeName": "20D"
            },
            {
                "SSR_TypeDesc": "SEAT - 20E",
                "SSR_TypeName": "20E"
            },
            {
                "SSR_TypeDesc": "SEAT - 20F",
                "SSR_TypeName": "20F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 21A",
                "SSR_TypeName": "21A"
            },
            {
                "SSR_TypeDesc": "SEAT - 21B",
                "SSR_TypeName": "21B"
            },
            {
                "SSR_TypeDesc": "SEAT - 21C",
                "SSR_TypeName": "21C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 21D",
                "SSR_TypeName": "21D"
            },
            {
                "SSR_TypeDesc": "SEAT - 21E",
                "SSR_TypeName": "21E"
            },
            {
                "SSR_TypeDesc": "SEAT - 21F",
                "SSR_TypeName": "21F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 22A",
                "SSR_TypeName": "22A"
            },
            {
                "SSR_TypeDesc": "SEAT - 22B",
                "SSR_TypeName": "22B"
            },
            {
                "SSR_TypeDesc": "SEAT - 22C",
                "SSR_TypeName": "22C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 22D",
                "SSR_TypeName": "22D"
            },
            {
                "SSR_TypeDesc": "SEAT - 22E",
                "SSR_TypeName": "22E"
            },
            {
                "SSR_TypeDesc": "SEAT - 22F",
                "SSR_TypeName": "22F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 23A",
                "SSR_TypeName": "23A"
            },
            {
                "SSR_TypeDesc": "SEAT - 23B",
                "SSR_TypeName": "23B"
            },
            {
                "SSR_TypeDesc": "SEAT - 23C",
                "SSR_TypeName": "23C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 23D",
                "SSR_TypeName": "23D"
            },
            {
                "SSR_TypeDesc": "SEAT - 23E",
                "SSR_TypeName": "23E"
            },
            {
                "SSR_TypeDesc": "SEAT - 23F",
                "SSR_TypeName": "23F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 24A",
                "SSR_TypeName": "24A"
            },
            {
                "SSR_TypeDesc": "SEAT - 24B",
                "SSR_TypeName": "24B"
            },
            {
                "SSR_TypeDesc": "SEAT - 24C",
                "SSR_TypeName": "24C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 24D",
                "SSR_TypeName": "24D"
            },
            {
                "SSR_TypeDesc": "SEAT - 24E",
                "SSR_TypeName": "24E"
            },
            {
                "SSR_TypeDesc": "SEAT - 24F",
                "SSR_TypeName": "24F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 25A",
                "SSR_TypeName": "25A"
            },
            {
                "SSR_TypeDesc": "SEAT - 25B",
                "SSR_TypeName": "25B"
            },
            {
                "SSR_TypeDesc": "SEAT - 25C",
                "SSR_TypeName": "25C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 25D",
                "SSR_TypeName": "25D"
            },
            {
                "SSR_TypeDesc": "SEAT - 25E",
                "SSR_TypeName": "25E"
            },
            {
                "SSR_TypeDesc": "SEAT - 25F",
                "SSR_TypeName": "25F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 26A",
                "SSR_TypeName": "26A"
            },
            {
                "SSR_TypeDesc": "SEAT - 26B",
                "SSR_TypeName": "26B"
            },
            {
                "SSR_TypeDesc": "SEAT - 26C",
                "SSR_TypeName": "26C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 26D",
                "SSR_TypeName": "26D"
            },
            {
                "SSR_TypeDesc": "SEAT - 26E",
                "SSR_TypeName": "26E"
            },
            {
                "SSR_TypeDesc": "SEAT - 26F",
                "SSR_TypeName": "26F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 27A",
                "SSR_TypeName": "27A"
            },
            {
                "SSR_TypeDesc": "SEAT - 27B",
                "SSR_TypeName": "27B"
            },
            {
                "SSR_TypeDesc": "SEAT - 27C",
                "SSR_TypeName": "27C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 27D",
                "SSR_TypeName": "27D"
            },
            {
                "SSR_TypeDesc": "SEAT - 27E",
                "SSR_TypeName": "27E"
            },
            {
                "SSR_TypeDesc": "SEAT - 27F",
                "SSR_TypeName": "27F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 28A",
                "SSR_TypeName": "28A"
            },
            {
                "SSR_TypeDesc": "SEAT - 28B",
                "SSR_TypeName": "28B"
            },
            {
                "SSR_TypeDesc": "SEAT - 28C",
                "SSR_TypeName": "28C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 28D",
                "SSR_TypeName": "28D"
            },
            {
                "SSR_TypeDesc": "SEAT - 28E",
                "SSR_TypeName": "28E"
            },
            {
                "SSR_TypeDesc": "SEAT - 28F",
                "SSR_TypeName": "28F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 29A",
                "SSR_TypeName": "29A"
            },
            {
                "SSR_TypeDesc": "SEAT - 29B",
                "SSR_TypeName": "29B"
            },
            {
                "SSR_TypeDesc": "SEAT - 29C",
                "SSR_TypeName": "29C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 29D",
                "SSR_TypeName": "29D"
            },
            {
                "SSR_TypeDesc": "SEAT - 29E",
                "SSR_TypeName": "29E"
            },
            {
                "SSR_TypeDesc": "SEAT - 29F",
                "SSR_TypeName": "29F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 30A",
                "SSR_TypeName": "30A"
            },
            {
                "SSR_TypeDesc": "SEAT - 30B",
                "SSR_TypeName": "30B"
            },
            {
                "SSR_TypeDesc": "SEAT - 30C",
                "SSR_TypeName": "30C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 30D",
                "SSR_TypeName": "30D"
            },
            {
                "SSR_TypeDesc": "SEAT - 30E",
                "SSR_TypeName": "30E"
            },
            {
                "SSR_TypeDesc": "SEAT - 30F",
                "SSR_TypeName": "30F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 31A",
                "SSR_TypeName": "31A"
            },
            {
                "SSR_TypeDesc": "SEAT - 31B",
                "SSR_TypeName": "31B"
            },
            {
                "SSR_TypeDesc": "SEAT - 31C",
                "SSR_TypeName": "31C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 31D",
                "SSR_TypeName": "31D"
            },
            {
                "SSR_TypeDesc": "SEAT - 31E",
                "SSR_TypeName": "31E"
            },
            {
                "SSR_TypeDesc": "SEAT - 31F",
                "SSR_TypeName": "31F"
            }
        ],
        [
            {
                "SSR_TypeDesc": "SEAT - 32A",
                "SSR_TypeName": "32A"
            },
            {
                "SSR_TypeDesc": "SEAT - 32B",
                "SSR_TypeName": "32B"
            },
            {
                "SSR_TypeDesc": "SEAT - 32C",
                "SSR_TypeName": "32C"
            },
            {
                "SSR_TypeDesc": null,
                "SSR_TypeName": null
            },
            {
                "SSR_TypeDesc": "SEAT - 32D",
                "SSR_TypeName": "32D"
            },
            {
                "SSR_TypeDesc": "SEAT - 32E",
                "SSR_TypeName": "32E"
            },
            {
                "SSR_TypeDesc": "SEAT - 32F",
                "SSR_TypeName": "32F"
            }
        ]
    ]
};

const SeatMap = () => {
    // Render the seats based on the flight data
    return (
        <div>
            <h1>Flight Seat Map</h1>
            <svg width="400" height="300" style={{ border: '1px solid #ccc' }}>
                {flightData.data.map((row, rowIndex) => 
                    row.map((seat, seatIndex) => {
                        const x = seatIndex * 80 + 50; // X position
                        const y = rowIndex * 80 + 30;  // Y position
                        return (
                            <g key={seat.SSR_TypeName} transform={`translate(${x}, ${y})`}>
                                <rect
                                    width="60"
                                    height="40"
                                    fill="#007BFF"
                                    stroke="#000"
                                    strokeWidth="1"
                                    style={{ cursor: 'pointer' }}
                                    onClick={() => alert(`You selected ${seat.SSR_TypeName}`)}
                                />
                                <text
                                    x="30"
                                    y="20"
                                    fill="#FFF"
                                    fontSize="12"
                                    textAnchor="middle"
                                    dominantBaseline="middle"
                                >
                                    {seat.SSR_TypeName}
                                </text>
                            </g>
                        );
                    })
                )}
            </svg>
        </div>
    );
};

export default SeatMap;
