import React from 'react'
import OrdersTable from '../components/Orderpage/OrdersTable'

const OrderPage = () => {
    return (
        <div>
            <OrdersTable />
        </div>
    )
}

export default OrderPage